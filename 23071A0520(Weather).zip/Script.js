const API_KEY = '8c72a5b86a406d4281b35d5f99200149'; // Replace with your API key

let weatherChart; // Global chart instance to control chart updates

// Fetch weather data using async/await
const fetchWeatherData = async (city) => {
  const response = await fetch(
    `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${API_KEY}`
  );
  if (!response.ok) throw new Error("City not found");
  return await response.json();
};

// Arrow function to prepare data for the chart
const prepareChartData = (data) => {
  return {
    labels: data.list.slice(0, 8).map(item => item.dt_txt),
    temps: data.list.slice(0, 8).map(item => item.main.temp)
  };
};

// Function to draw the chart (using callback)
const drawChart = ({ labels, temps }) => {
  const canvas = document.getElementById("weatherChart");
  const ctx = canvas.getContext("2d");

  // Destroy previous chart if exists to avoid overlapping
  if (weatherChart) {
    weatherChart.destroy();
  }

  // Create a new chart
  weatherChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels,
      datasets: [{
        label: "Temperature (°C)",
        data: temps,
        backgroundColor: "#12345855",
        borderColor: "#581212",
        borderWidth: 2,
        fill: true
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          labels: {
            color: "#000"
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: "#000"
          }
        },
        y: {
          beginAtZero: false,
          ticks: {
            color: "#000"
          }
        }
      }
    }
  });
};

// Event listener for the "Get Weather" button
document.getElementById("getWeatherBtn").addEventListener("click", async () => {
  const city = document.getElementById("cityInput").value;
  if (!city) return alert("Please enter a city");

  try {
    const data = await fetchWeatherData(city); // Using async/await to fetch data
    const chartData = prepareChartData(data);  // Prepare the chart data using arrow function
    drawChart(chartData); // Draw the chart using callback
  } catch (error) {
    alert(error.message); // Display error if city not found
  }
});

// Event listener for the "Reset" button to clear the input and the chart
document.getElementById("resetBtn").addEventListener("click", () => {
  // Clear the input field
  document.getElementById("cityInput").value = '';

  // Clear the chart
  const canvas = document.getElementById("weatherChart");
  const ctx = canvas.getContext("2d");
  if (weatherChart) {
    weatherChart.destroy();
  }

  // Optionally, reset the UI or show a message
  alert("Input cleared and chart reset.");
});
